#include <stdio.h>
#include <string.h>

int main()
{
	char nome1[30], nome2[30];
	int i;

	printf("Primeiro Nome: ");
	gets(nome1);

	printf("Segudno Nome: ");
	gets(nome2);

	printf("\nNOMES EM ORDEM ALFABETICA\n");
	
	//-1 = n1 < n2 
	// 1 = n1 > n2
	// 0 = n1 == n2
	
	if(strcmp(nome1, nome2) < 0){
		printf("\n%s\n%s\n", nome1, nome2);
	}else if(strcmp(nome1, nome2) > 0){
		printf("\n%s\n%s\n", nome2, nome1);
	}
	getch ();
	return 0;
}
