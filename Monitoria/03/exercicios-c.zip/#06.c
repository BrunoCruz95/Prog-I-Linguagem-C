#include <stdio.h>

int main()
{
	int num, var;

	printf("Digite: ");
	scanf("%d", &num);
	
	printf("%d", num % 10);
	//printf("%d", num % 100);
	//printf("%d", num % 10);
	getch();
	return 0;
}
