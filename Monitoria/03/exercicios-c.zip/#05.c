#include <stdio.h>

int main()
{
	int num ;
	printf("Digite: ");
	scanf("%d", &num);

	printf("%x", num); //HEXADECIMAL

	getch();
	return 0;
}
